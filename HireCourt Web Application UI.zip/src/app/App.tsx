import { useState, useRef, useEffect } from "react";
import {
  LogOut, User, Home, Users, Plus, Upload, Mic, MicOff,
  ChevronLeft, ChevronRight, CheckCircle, XCircle, Mail,
  Save, ArrowLeft, Search, Trash2, ChevronDown, Eye,
  CheckSquare, Square, BarChart2, FileText, Briefcase, Star,
  Send, Filter, SortAsc, X
} from "lucide-react";

type Page = "login" | "dashboard" | "new-candidate" | "interview" | "results" | "previous-candidates";

interface Candidate {
  id: string;
  name: string;
  position: string;
  email: string;
  score: number;
  date: string;
  questions: { question: string; answer: string; evaluation: "Excellent" | "Good answer" | "Needs improvement" }[];
}

const JOB_POSITIONS = [
  "Project Manager",
  "Financial Analyst",
  "Digital Marketing Specialist",
  "Backend Developer",
  "Data Analyst",
];

const SAMPLE_QUESTIONS: Record<string, string[]> = {
  "Project Manager": [
    "Describe a time you managed a project with tight deadlines. How did you prioritize tasks?",
    "How do you handle conflicts within your project team?",
    "What methodologies do you prefer for project management and why?",
    "How do you manage scope creep in a project?",
    "Describe your experience with stakeholder communication.",
    "What KPIs do you use to measure project success?",
    "How do you handle underperforming team members?",
    "Describe a failed project and what you learned from it.",
    "How do you estimate project timelines and budgets?",
    "What tools do you use for project tracking and why?",
  ],
  "Financial Analyst": [
    "Walk me through a DCF analysis you've completed.",
    "How do you approach financial modeling for a new business unit?",
    "Describe your experience with variance analysis.",
    "How do you communicate financial insights to non-finance stakeholders?",
    "What financial software and tools are you proficient in?",
    "How do you identify and mitigate financial risks?",
    "Describe a time you found a significant discrepancy in financial data.",
    "How do you stay current with regulatory changes affecting financial reporting?",
    "What is your process for building a budget from scratch?",
    "How do you approach cost-benefit analysis for capital expenditures?",
  ],
  "Digital Marketing Specialist": [
    "Describe a successful digital campaign you led. What metrics did you track?",
    "How do you approach SEO strategy for a new product launch?",
    "What is your experience with paid social and search advertising?",
    "How do you measure and optimize conversion rates?",
    "Describe your content marketing strategy framework.",
    "How do you handle a campaign that is not meeting its KPIs?",
    "What marketing automation tools have you worked with?",
    "How do you approach audience segmentation and targeting?",
    "Describe your experience with A/B testing.",
    "How do you stay up to date with algorithm changes on major platforms?",
  ],
  "Backend Developer": [
    "Describe your experience designing RESTful APIs.",
    "How do you approach database schema design for scalability?",
    "What is your strategy for handling authentication and authorization?",
    "Describe a performance bottleneck you identified and resolved.",
    "How do you approach microservices architecture versus monolithic systems?",
    "What is your testing strategy for backend services?",
    "How do you handle versioning in APIs?",
    "Describe your experience with cloud infrastructure and deployment pipelines.",
    "How do you approach error handling and logging in production systems?",
    "What security best practices do you follow in backend development?",
  ],
  "Data Analyst": [
    "Walk me through your process for cleaning and preparing a messy dataset.",
    "How do you translate complex data findings into actionable insights?",
    "Describe your experience with SQL and the most complex query you have written.",
    "What visualization tools do you prefer and why?",
    "How do you approach building a KPI dashboard from scratch?",
    "Describe a time when data analysis led to a significant business decision.",
    "How do you handle missing or inconsistent data?",
    "What statistical methods do you use most frequently in your work?",
    "How do you validate the accuracy of your analysis?",
    "Describe your experience with Python or R for data analysis.",
  ],
};

const SAMPLE_CANDIDATES: Candidate[] = [
  {
    id: "1",
    name: "Sarah Mitchell",
    position: "Backend Developer",
    email: "sarah.mitchell@email.com",
    score: 87,
    date: "2025-05-14",
    questions: [
      { question: "Describe your experience designing RESTful APIs.", answer: "I have built RESTful APIs for 4 years across fintech and healthcare. My approach focuses on clear versioning, consistent error responses, and thorough OpenAPI documentation.", evaluation: "Excellent" },
      { question: "How do you approach database schema design for scalability?", answer: "I start with normalization then strategically denormalize based on read patterns. I use indexing carefully and always plan for horizontal sharding from day one.", evaluation: "Good answer" },
    ],
  },
  {
    id: "2",
    name: "James Okonkwo",
    position: "Data Analyst",
    email: "james.okonkwo@email.com",
    score: 72,
    date: "2025-05-12",
    questions: [
      { question: "Walk me through your process for cleaning and preparing a messy dataset.", answer: "I start with exploratory analysis, then handle nulls based on statistical context—mean imputation for numerical, mode for categorical. I document every transformation.", evaluation: "Good answer" },
    ],
  },
  {
    id: "3",
    name: "Priya Sharma",
    position: "Project Manager",
    email: "priya.sharma@email.com",
    score: 54,
    date: "2025-05-10",
    questions: [
      { question: "Describe a time you managed a project with tight deadlines.", answer: "We had a product launch compressed from 6 weeks to 3. I broke work into daily sprints and ran daily standups to catch blockers early.", evaluation: "Needs improvement" },
    ],
  },
  {
    id: "4",
    name: "Lucas Fernandez",
    position: "Financial Analyst",
    email: "lucas.fernandez@email.com",
    score: 91,
    date: "2025-05-08",
    questions: [
      { question: "Walk me through a DCF analysis you have completed.", answer: "I built a 5-year DCF for a SaaS acquisition. I modeled three scenarios—base, bull, bear—with sensitivity tables on WACC and terminal growth rate.", evaluation: "Excellent" },
    ],
  },
  {
    id: "5",
    name: "Amara Diallo",
    position: "Digital Marketing Specialist",
    email: "amara.diallo@email.com",
    score: 65,
    date: "2025-05-06",
    questions: [
      { question: "Describe a successful digital campaign you led.", answer: "Ran a LinkedIn + Google Ads campaign for a B2B SaaS product. We achieved 340% ROAS in 90 days by iterating on audience segments weekly.", evaluation: "Good answer" },
    ],
  },
];

function Logo({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  const sizes = { sm: "text-lg", md: "text-xl", lg: "text-3xl" };
  return (
    <div className={`flex items-center gap-2 font-display font-bold ${sizes[size]}`}>
      <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center shadow-lg shadow-primary/30">
        <Briefcase className="w-4 h-4 text-white" />
      </div>
      <span className="text-primary">Hire</span>
      <span className="text-foreground">Court</span>
    </div>
  );
}

function ScoreRing({ score }: { score: number }) {
  const ringColor = score >= 80 ? "#7C3AED" : score >= 60 ? "#F59E0B" : "#EAB308";
  const circumference = 2 * Math.PI * 44;
  const dash = (score / 100) * circumference;

  return (
    <div className="relative w-32 h-32 flex items-center justify-center">
      <svg className="absolute inset-0 -rotate-90" width="128" height="128" viewBox="0 0 128 128">
        <circle cx="64" cy="64" r="44" fill="none" stroke="#F3E8FF" strokeWidth="12" />
        <circle
          cx="64" cy="64" r="44" fill="none"
          stroke={ringColor} strokeWidth="12"
          strokeDasharray={`${dash} ${circumference}`}
          strokeLinecap="round"
          style={{ transition: "stroke-dasharray 1s ease" }}
        />
      </svg>
      <div className="bg-accent rounded-full w-20 h-20 flex flex-col items-center justify-center z-10">
        <span className="text-2xl font-bold text-primary">{score}</span>
        <span className="text-xs text-muted-foreground font-medium">/100</span>
      </div>
    </div>
  );
}

function EvalBadge({ eval: ev }: { eval: "Excellent" | "Good answer" | "Needs improvement" }) {
  const styles = {
    "Excellent": "bg-violet-100 text-violet-700 border-violet-200",
    "Good answer": "bg-amber-50 text-amber-700 border-amber-200",
    "Needs improvement": "bg-yellow-50 text-yellow-700 border-yellow-200",
  };
  return (
    <span className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${styles[ev]}`}>{ev}</span>
  );
}

// ─── LOGIN PAGE ───────────────────────────────────────────────────────────────
function LoginPage({ onLogin }: { onLogin: () => void }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => { setLoading(false); onLogin(); }, 1000);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 w-96 h-96 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full bg-primary/8 blur-3xl" />
      </div>
      <div className="relative w-full max-w-md">
        <div className="bg-card rounded-2xl shadow-xl shadow-primary/10 border border-border p-10">
          <div className="flex flex-col items-center mb-10">
            <Logo size="lg" />
            <p className="mt-3 text-muted-foreground text-sm">AI-Powered Interview Platform</p>
          </div>
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-semibold text-foreground mb-1.5">Email Address</label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="hr@company.com"
                required
                className="w-full px-4 py-3 rounded-xl bg-input-background border border-border text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-foreground mb-1.5">Password</label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full px-4 py-3 rounded-xl bg-input-background border border-border text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all"
              />
            </div>
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold text-base hover:bg-primary/90 active:scale-[0.98] transition-all shadow-lg shadow-primary/25 disabled:opacity-70 mt-2"
            >
              {loading ? "Signing in…" : "Login"}
            </button>
          </form>
          <p className="text-center text-xs text-muted-foreground mt-6">
            Demo: any email & password to continue
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── HEADER ───────────────────────────────────────────────────────────────────
function Header({ currentPage, onNav, onLogout }: {
  currentPage: Page;
  onNav: (p: Page) => void;
  onLogout: () => void;
}) {
  const navItems: { label: string; page: Page }[] = [
    { label: "Home", page: "dashboard" },
    { label: "New Candidate", page: "new-candidate" },
    { label: "Previous Candidates", page: "previous-candidates" },
  ];

  return (
    <header className="sticky top-0 z-50 bg-card/90 backdrop-blur-md border-b border-border shadow-sm shadow-primary/5">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between gap-4">
        <Logo size="md" />
        <nav className="hidden md:flex items-center gap-1">
          {navItems.map(item => (
            <button
              key={item.page}
              onClick={() => onNav(item.page)}
              className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                currentPage === item.page
                  ? "bg-primary text-primary-foreground shadow shadow-primary/20"
                  : "text-muted-foreground hover:text-foreground hover:bg-muted"
              }`}
            >
              {item.label}
            </button>
          ))}
        </nav>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-full bg-gradient-to-br from-primary/80 to-secondary flex items-center justify-center shadow-md shadow-primary/20 border-2 border-white">
            <User className="w-4 h-4 text-primary-foreground" />
          </div>
          <button
            onClick={onLogout}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-semibold text-muted-foreground hover:text-destructive hover:bg-destructive/5 transition-all"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Logout</span>
          </button>
        </div>
      </div>
    </header>
  );
}

// ─── DASHBOARD ────────────────────────────────────────────────────────────────
function Dashboard({ onNav }: { onNav: (p: Page) => void }) {
  return (
    <div className="max-w-7xl mx-auto px-6 py-12">
      <div className="mb-10">
        <h1 className="text-3xl font-display font-bold text-foreground">Welcome back, HR Manager</h1>
        <p className="text-muted-foreground mt-1">Manage your interview pipeline with AI precision.</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-3xl">
        <button
          onClick={() => onNav("new-candidate")}
          className="group bg-primary rounded-2xl p-8 text-left shadow-xl shadow-primary/25 hover:shadow-2xl hover:shadow-primary/35 hover:-translate-y-1 transition-all duration-200"
        >
          <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center mb-5 group-hover:bg-white/30 transition-colors">
            <Plus className="w-6 h-6 text-white" />
          </div>
          <h2 className="text-xl font-display font-bold text-white">Start New Interview</h2>
          <p className="text-white/70 text-sm mt-1.5">Upload CV and begin AI-powered assessment</p>
        </button>
        <button
          onClick={() => onNav("previous-candidates")}
          className="group bg-card rounded-2xl p-8 text-left border border-border shadow-lg shadow-primary/5 hover:shadow-xl hover:shadow-primary/12 hover:-translate-y-1 hover:border-primary/30 transition-all duration-200"
        >
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary/15 transition-colors">
            <Users className="w-6 h-6 text-primary" />
          </div>
          <h2 className="text-xl font-display font-bold text-foreground">View Previous Candidates</h2>
          <p className="text-muted-foreground text-sm mt-1.5">Review past interviews, scores, and decisions</p>
        </button>
      </div>
      <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total Interviews", value: SAMPLE_CANDIDATES.length, icon: BarChart2 },
          { label: "Avg. Score", value: `${Math.round(SAMPLE_CANDIDATES.reduce((a, c) => a + c.score, 0) / SAMPLE_CANDIDATES.length)}`, icon: Star },
          { label: "Positions Open", value: JOB_POSITIONS.length, icon: Briefcase },
          { label: "Emails Sent", value: "12", icon: Mail },
        ].map(stat => (
          <div key={stat.label} className="bg-card rounded-xl border border-border p-5 shadow-sm">
            <stat.icon className="w-5 h-5 text-primary mb-3" />
            <div className="text-2xl font-bold text-foreground">{stat.value}</div>
            <div className="text-xs text-muted-foreground mt-0.5">{stat.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── NEW CANDIDATE ─────────────────────────────────────────────────────────────
function NewCandidatePage({ onStart, onCancel }: {
  onStart: (candidate: { name: string; position: string; email: string }) => void;
  onCancel: () => void;
}) {
  const [name, setName] = useState("");
  const [position, setPosition] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [extractedEmail, setExtractedEmail] = useState("");
  const [extracting, setExtracting] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFile = (f: File) => {
    setFile(f);
    setExtracting(true);
    setTimeout(() => {
      const fake = `${name.toLowerCase().replace(/\s+/, ".") || "candidate"}@email.com`;
      setExtractedEmail(fake);
      setExtracting(false);
    }, 1500);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const f = e.dataTransfer.files[0];
    if (f && f.type === "application/pdf") handleFile(f);
  };

  return (
    <div className="max-w-2xl mx-auto px-6 py-12">
      <button onClick={onCancel} className="flex items-center gap-2 text-muted-foreground hover:text-primary text-sm font-semibold mb-8 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back
      </button>
      <h1 className="text-2xl font-display font-bold text-foreground mb-2">New Candidate</h1>
      <p className="text-muted-foreground text-sm mb-8">Fill in the details below to begin the AI interview process.</p>

      <div className="bg-card rounded-2xl border border-border shadow-lg shadow-primary/5 p-8 space-y-6">
        <div>
          <label className="block text-sm font-semibold text-foreground mb-1.5">Candidate Name</label>
          <input
            type="text"
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="e.g. Sarah Mitchell"
            className="w-full px-4 py-3 rounded-xl bg-input-background border border-border text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all"
          />
        </div>
        <div>
          <label className="block text-sm font-semibold text-foreground mb-1.5">Job Position</label>
          <div className="relative">
            <select
              value={position}
              onChange={e => setPosition(e.target.value)}
              className="w-full px-4 py-3 rounded-xl bg-input-background border border-border text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all appearance-none cursor-pointer"
            >
              <option value="">Select a position…</option>
              {JOB_POSITIONS.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
            <ChevronDown className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold text-foreground mb-1.5">Upload CV</label>
          <div
            onDrop={handleDrop}
            onDragOver={e => e.preventDefault()}
            onClick={() => fileRef.current?.click()}
            className="border-2 border-dashed border-primary/25 rounded-xl p-8 flex flex-col items-center gap-3 cursor-pointer hover:border-primary/50 hover:bg-primary/3 transition-all"
          >
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <Upload className="w-5 h-5 text-primary" />
            </div>
            {file ? (
              <div className="text-center">
                <p className="text-sm font-semibold text-primary">{file.name}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{(file.size / 1024).toFixed(0)} KB · PDF</p>
              </div>
            ) : (
              <div className="text-center">
                <p className="text-sm font-semibold text-foreground">Drop PDF here or click to browse</p>
                <p className="text-xs text-muted-foreground mt-0.5">PDF files only · Max 10 MB</p>
              </div>
            )}
            <input ref={fileRef} type="file" accept=".pdf" className="hidden" onChange={e => { if (e.target.files?.[0]) handleFile(e.target.files[0]); }} />
          </div>
        </div>

        {(extracting || extractedEmail) && (
          <div className={`flex items-center gap-3 px-4 py-3 rounded-xl border ${extracting ? "bg-muted border-border" : "bg-accent border-primary/20"}`}>
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${extracting ? "bg-muted-foreground/20" : "bg-primary/15"}`}>
              <Mail className={`w-4 h-4 ${extracting ? "text-muted-foreground animate-pulse" : "text-primary"}`} />
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground">Extracted from CV</p>
              {extracting ? (
                <p className="text-sm text-muted-foreground animate-pulse">Extracting email…</p>
              ) : (
                <p className="text-sm font-semibold text-foreground">{extractedEmail}</p>
              )}
            </div>
          </div>
        )}

        <div className="flex gap-3 pt-2">
          <button
            onClick={() => name && position && file && !extracting && onStart({ name, position, email: extractedEmail })}
            disabled={!name || !position || !file || extracting}
            className="flex-1 py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 active:scale-[0.98] transition-all shadow-lg shadow-primary/25 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Start Interview
          </button>
          <button
            onClick={onCancel}
            className="px-6 py-3.5 rounded-xl border border-border text-foreground font-semibold text-sm hover:bg-muted transition-all"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── INTERVIEW PAGE ────────────────────────────────────────────────────────────
function InterviewPage({ candidate, onFinish }: {
  candidate: { name: string; position: string; email: string };
  onFinish: (answers: { question: string; answer: string; evaluation: "Excellent" | "Good answer" | "Needs improvement" }[]) => void;
}) {
  const questions = SAMPLE_QUESTIONS[candidate.position] || SAMPLE_QUESTIONS["Backend Developer"];
  const total = questions.length;
  const [current, setCurrent] = useState(0);
  const [answers, setAnswers] = useState<string[]>(Array(total).fill(""));
  const [recording, setRecording] = useState(false);

  const setAnswer = (val: string) => {
    const next = [...answers];
    next[current] = val;
    setAnswers(next);
  };

  const evaluations: Array<"Excellent" | "Good answer" | "Needs improvement"> = ["Excellent", "Good answer", "Needs improvement", "Excellent", "Good answer", "Needs improvement", "Excellent", "Good answer", "Needs improvement", "Good answer"];

  const handleFinish = () => {
    const result = questions.map((q, i) => ({
      question: q,
      answer: answers[i] || "No answer provided.",
      evaluation: evaluations[i % 3] as "Excellent" | "Good answer" | "Needs improvement",
    }));
    onFinish(result);
  };

  const handleVoice = () => {
    setRecording(r => !r);
    if (recording) {
      setTimeout(() => {
        setAnswer(answers[current] + (answers[current] ? " " : "") + "[Voice transcription: detailed response about the topic with specific examples and metrics from past experience.]");
        setRecording(false);
      }, 2000);
    }
  };

  const progress = ((current + 1) / total) * 100;

  return (
    <div className="max-w-3xl mx-auto px-6 py-12">
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="font-display font-bold text-xl text-foreground">{candidate.name}</h1>
          <p className="text-muted-foreground text-sm">{candidate.position}</p>
        </div>
        <span className="text-sm font-semibold text-primary bg-primary/10 px-4 py-2 rounded-full">
          Question {current + 1} of {total}
        </span>
      </div>

      <div className="mb-8">
        <div className="h-2 bg-muted rounded-full overflow-hidden">
          <div
            className="h-full bg-primary rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      <div className="bg-card rounded-2xl border border-border shadow-lg shadow-primary/5 p-8 mb-6">
        <div className="flex items-start gap-4 mb-6">
          <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0 mt-0.5">
            <span className="text-sm font-bold text-primary">Q{current + 1}</span>
          </div>
          <p className="text-foreground font-semibold text-lg leading-relaxed">{questions[current]}</p>
        </div>

        <div className="relative">
          <textarea
            value={answers[current]}
            onChange={e => setAnswer(e.target.value)}
            placeholder="Type your answer here…"
            rows={5}
            className="w-full px-4 py-3 rounded-xl bg-input-background border border-border text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all resize-none pr-14"
          />
          <button
            onClick={handleVoice}
            className={`absolute right-3 bottom-3 w-9 h-9 rounded-lg flex items-center justify-center transition-all ${
              recording
                ? "bg-destructive text-white animate-pulse"
                : "bg-primary/10 text-primary hover:bg-primary/20"
            }`}
            title={recording ? "Stop recording" : "Record voice answer"}
          >
            {recording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
          </button>
        </div>
        {recording && (
          <p className="text-xs text-destructive font-semibold mt-2 animate-pulse flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-destructive inline-block" />
            Recording… speak your answer
          </p>
        )}
      </div>

      <div className="flex items-center gap-3">
        <button
          onClick={() => setCurrent(c => Math.max(0, c - 1))}
          disabled={current === 0}
          className="flex items-center gap-2 px-5 py-3 rounded-xl border border-border text-foreground font-semibold text-sm hover:bg-muted disabled:opacity-40 disabled:cursor-not-allowed transition-all"
        >
          <ChevronLeft className="w-4 h-4" /> Previous
        </button>
        <div className="flex-1" />
        {current < total - 1 ? (
          <button
            onClick={() => setCurrent(c => c + 1)}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 shadow-lg shadow-primary/25 transition-all"
          >
            Next Question <ChevronRight className="w-4 h-4" />
          </button>
        ) : null}
        <button
          onClick={handleFinish}
          className="flex items-center gap-2 px-6 py-3 rounded-xl bg-primary/10 text-primary border border-primary/20 font-semibold text-sm hover:bg-primary/20 transition-all"
        >
          <CheckCircle className="w-4 h-4" /> Finish Interview
        </button>
      </div>
    </div>
  );
}

// ─── RESULTS PAGE ──────────────────────────────────────────────────────────────
function ResultsPage({ candidate, onBack, onSave }: {
  candidate: Candidate;
  onBack: () => void;
  onSave: (c: Candidate) => void;
}) {
  const [emailSent, setEmailSent] = useState<"" | "acceptance" | "rejection">("");

  const sendEmail = (type: "acceptance" | "rejection") => {
    setEmailSent(type);
    setTimeout(() => setEmailSent(""), 3000);
  };

  return (
    <div className="max-w-3xl mx-auto px-6 py-12">
      <button onClick={onBack} className="flex items-center gap-2 text-muted-foreground hover:text-primary text-sm font-semibold mb-8 transition-colors">
        <ArrowLeft className="w-4 h-4" /> Back to Candidates
      </button>

      {/* Candidate Info */}
      <div className="bg-card rounded-2xl border border-border shadow-lg shadow-primary/5 p-8 mb-6">
        <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-6">Candidate Information</h2>
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-6">
          <div className="flex-1 space-y-3">
            <div>
              <p className="text-xs text-muted-foreground font-medium">Name</p>
              <p className="font-display font-bold text-xl text-foreground">{candidate.name}</p>
            </div>
            <div className="flex gap-6">
              <div>
                <p className="text-xs text-muted-foreground font-medium">Position</p>
                <p className="font-semibold text-foreground text-sm">{candidate.position}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground font-medium">Email</p>
                <p className="font-semibold text-foreground text-sm">{candidate.email}</p>
              </div>
            </div>
            <button className="flex items-center gap-2 text-xs font-semibold text-primary bg-primary/10 hover:bg-primary/20 px-3 py-1.5 rounded-lg transition-colors">
              <FileText className="w-3.5 h-3.5" /> View CV
            </button>
          </div>
          <div className="flex flex-col items-center gap-2">
            <ScoreRing score={candidate.score} />
            <p className="text-xs font-semibold text-muted-foreground">Final Score</p>
          </div>
        </div>
      </div>

      {/* Q&A */}
      <div className="bg-card rounded-2xl border border-border shadow-lg shadow-primary/5 p-8 mb-6">
        <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-6">Questions & Answers</h2>
        <div className="space-y-6">
          {candidate.questions.map((qa, i) => (
            <div key={i} className="pb-6 border-b border-border last:border-0 last:pb-0">
              <div className="flex items-start justify-between gap-4 mb-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-primary bg-primary/10 px-2 py-0.5 rounded-md">Q{i + 1}</span>
                  <p className="text-sm font-semibold text-foreground">{qa.question}</p>
                </div>
                <EvalBadge eval={qa.evaluation} />
              </div>
              <p className="text-sm text-muted-foreground pl-10 leading-relaxed">{qa.answer}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Email Actions */}
      <div className="bg-card rounded-2xl border border-border shadow-lg shadow-primary/5 p-8 mb-6">
        <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2">Email Actions</h2>
        <p className="text-xs text-muted-foreground mb-6">Sending to: <span className="font-semibold text-foreground">{candidate.email}</span></p>
        {emailSent && (
          <div className={`mb-4 px-4 py-3 rounded-xl text-sm font-semibold flex items-center gap-2 ${emailSent === "acceptance" ? "bg-violet-50 text-violet-700 border border-violet-200" : "bg-red-50 text-red-600 border border-red-100"}`}>
            <CheckCircle className="w-4 h-4" />
            {emailSent === "acceptance" ? "Acceptance" : "Rejection"} email sent to {candidate.email}
          </div>
        )}
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            onClick={() => sendEmail("acceptance")}
            className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 shadow-lg shadow-primary/25 transition-all"
          >
            <CheckCircle className="w-4 h-4" /> Send Acceptance Email
          </button>
          <button
            onClick={() => sendEmail("rejection")}
            className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border border-destructive/30 text-destructive font-semibold text-sm hover:bg-destructive/5 transition-all"
          >
            <XCircle className="w-4 h-4" /> Send Rejection Email
          </button>
        </div>
      </div>

      {/* Admin Buttons */}
      <div className="flex gap-3">
        <button
          onClick={() => onSave(candidate)}
          className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold text-sm hover:bg-primary/90 shadow-lg shadow-primary/25 transition-all"
        >
          <Save className="w-4 h-4" /> Save Candidate
        </button>
        <button
          onClick={onBack}
          className="flex items-center gap-2 px-6 py-3.5 rounded-xl border border-border text-foreground font-semibold text-sm hover:bg-muted transition-all"
        >
          <ArrowLeft className="w-4 h-4" /> Back
        </button>
      </div>
    </div>
  );
}

// ─── PREVIOUS CANDIDATES ───────────────────────────────────────────────────────
function PreviousCandidatesPage({
  candidates,
  onViewDetails,
  onDelete,
}: {
  candidates: Candidate[];
  onViewDetails: (c: Candidate) => void;
  onDelete: (ids: string[]) => void;
}) {
  const [search, setSearch] = useState("");
  const [selectMode, setSelectMode] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [sortOpen, setSortOpen] = useState(false);
  const [filterOpen, setFilterOpen] = useState(false);
  const [sort, setSort] = useState<"date-desc" | "date-asc" | "score-desc" | "score-asc">("date-desc");
  const [filterPosition, setFilterPosition] = useState("All");
  const [bulkEmailSent, setBulkEmailSent] = useState<"" | "acceptance" | "rejection">("");
  const sortRef = useRef<HTMLDivElement>(null);
  const filterRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (sortRef.current && !sortRef.current.contains(e.target as Node)) setSortOpen(false);
      if (filterRef.current && !filterRef.current.contains(e.target as Node)) setFilterOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const filtered = candidates
    .filter(c => c.name.toLowerCase().includes(search.toLowerCase()))
    .filter(c => filterPosition === "All" || c.position === filterPosition)
    .sort((a, b) => {
      if (sort === "date-desc") return b.date.localeCompare(a.date);
      if (sort === "date-asc") return a.date.localeCompare(b.date);
      if (sort === "score-desc") return b.score - a.score;
      return a.score - b.score;
    });

  const toggleSelect = (id: string) => {
    const next = new Set(selected);
    next.has(id) ? next.delete(id) : next.add(id);
    setSelected(next);
  };

  const toggleAll = () => {
    if (selected.size === filtered.length) setSelected(new Set());
    else setSelected(new Set(filtered.map(c => c.id)));
  };

  const exitSelect = () => { setSelectMode(false); setSelected(new Set()); };

  const bulkEmail = (type: "acceptance" | "rejection") => {
    setBulkEmailSent(type);
    setTimeout(() => setBulkEmailSent(""), 3000);
  };

  const scoreColor = (score: number) =>
    score >= 80 ? "text-violet-600 bg-violet-50" : score >= 60 ? "text-amber-600 bg-amber-50" : "text-yellow-600 bg-yellow-50";

  const sortLabels = {
    "date-desc": "Newest First",
    "date-asc": "Oldest First",
    "score-desc": "Highest Score",
    "score-asc": "Lowest Score",
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-10">
      <div className="mb-8">
        <h1 className="text-2xl font-display font-bold text-foreground">Previous Candidates</h1>
        <p className="text-muted-foreground text-sm mt-1">{candidates.length} candidates on record</p>
      </div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6">
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by name…"
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-input-background border border-border text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary transition-all text-sm"
          />
        </div>

        {/* Sort Dropdown */}
        <div className="relative" ref={sortRef}>
          <button
            onClick={() => { setSortOpen(o => !o); setFilterOpen(false); }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border bg-card text-sm font-semibold text-foreground hover:bg-muted transition-all whitespace-nowrap"
          >
            <SortAsc className="w-4 h-4 text-primary" />
            {sortLabels[sort]}
            <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
          {sortOpen && (
            <div className="absolute right-0 top-full mt-2 bg-card border border-border rounded-xl shadow-xl shadow-primary/10 py-1.5 z-50 min-w-[180px]">
              {[
                { value: "date-desc", label: "Newest First" },
                { value: "date-asc", label: "Oldest First" },
                { value: "score-desc", label: "Highest Score" },
                { value: "score-asc", label: "Lowest Score" },
              ].map(opt => (
                <button
                  key={opt.value}
                  onClick={() => { setSort(opt.value as typeof sort); setSortOpen(false); }}
                  className={`w-full text-left px-4 py-2 text-sm font-medium transition-colors ${sort === opt.value ? "text-primary bg-primary/8" : "text-foreground hover:bg-muted"}`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Filter Dropdown */}
        <div className="relative" ref={filterRef}>
          <button
            onClick={() => { setFilterOpen(o => !o); setSortOpen(false); }}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border bg-card text-sm font-semibold text-foreground hover:bg-muted transition-all whitespace-nowrap"
          >
            <Filter className="w-4 h-4 text-primary" />
            {filterPosition === "All" ? "All Positions" : filterPosition}
            <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
          {filterOpen && (
            <div className="absolute right-0 top-full mt-2 bg-card border border-border rounded-xl shadow-xl shadow-primary/10 py-1.5 z-50 min-w-[220px]">
              {["All", ...JOB_POSITIONS].map(pos => (
                <button
                  key={pos}
                  onClick={() => { setFilterPosition(pos); setFilterOpen(false); }}
                  className={`w-full text-left px-4 py-2 text-sm font-medium transition-colors ${filterPosition === pos ? "text-primary bg-primary/8" : "text-foreground hover:bg-muted"}`}
                >
                  {pos === "All" ? "All Positions" : pos}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Select Mode */}
        <button
          onClick={() => selectMode ? exitSelect() : setSelectMode(true)}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-semibold transition-all whitespace-nowrap ${selectMode ? "bg-primary text-primary-foreground border-primary shadow-lg shadow-primary/25" : "border-border bg-card text-foreground hover:bg-muted"}`}
        >
          <CheckSquare className="w-4 h-4" />
          {selectMode ? "Exit Select" : "Select Candidates"}
        </button>
      </div>

      {/* Bulk Actions */}
      {selectMode && selected.size > 0 && (
        <div className="mb-4 flex flex-wrap items-center gap-3 px-5 py-3.5 bg-primary/5 border border-primary/20 rounded-xl">
          <span className="text-sm font-semibold text-primary">{selected.size} selected</span>
          <div className="flex-1" />
          {bulkEmailSent && (
            <span className="text-xs font-semibold text-primary bg-primary/10 px-3 py-1.5 rounded-lg">
              {bulkEmailSent === "acceptance" ? "Acceptance" : "Rejection"} emails sent!
            </span>
          )}
          <button onClick={() => bulkEmail("acceptance")} className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-primary text-primary-foreground text-xs font-semibold hover:bg-primary/90 transition-all shadow shadow-primary/20">
            <CheckCircle className="w-3.5 h-3.5" /> Send Acceptance
          </button>
          <button onClick={() => bulkEmail("rejection")} className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-destructive/30 text-destructive text-xs font-semibold hover:bg-destructive/5 transition-all">
            <XCircle className="w-3.5 h-3.5" /> Send Rejection
          </button>
          <button onClick={() => { onDelete([...selected]); exitSelect(); }} className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-destructive text-white text-xs font-semibold hover:bg-destructive/90 transition-all">
            <Trash2 className="w-3.5 h-3.5" /> Delete Selected
          </button>
        </div>
      )}

      {/* Table */}
      <div className="bg-card rounded-2xl border border-border shadow-lg shadow-primary/5 overflow-hidden">
        {/* Table Header */}
        <div className={`grid gap-4 px-6 py-3.5 bg-muted/50 border-b border-border text-xs font-bold uppercase tracking-widest text-muted-foreground ${selectMode ? "grid-cols-[32px_1fr_1fr_80px_100px_120px]" : "grid-cols-[1fr_1fr_80px_100px_120px]"}`}>
          {selectMode && (
            <div className="flex items-center">
              <button onClick={toggleAll} className="text-primary hover:text-primary/70 transition-colors">
                {selected.size === filtered.length && filtered.length > 0
                  ? <CheckSquare className="w-4 h-4" />
                  : <Square className="w-4 h-4" />}
              </button>
            </div>
          )}
          <span>Name</span>
          <span>Position</span>
          <span>Score</span>
          <span>Date</span>
          <span className="text-right">Action</span>
        </div>

        {filtered.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
            <Users className="w-10 h-10 mb-3 opacity-40" />
            <p className="text-sm font-semibold">No candidates found</p>
          </div>
        ) : (
          <div>
            {filtered.map((c, i) => (
              <div
                key={c.id}
                className={`grid gap-4 px-6 py-4 items-center transition-colors ${i < filtered.length - 1 ? "border-b border-border" : ""} ${selected.has(c.id) ? "bg-primary/5" : "hover:bg-muted/40"} ${selectMode ? "grid-cols-[32px_1fr_1fr_80px_100px_120px]" : "grid-cols-[1fr_1fr_80px_100px_120px]"}`}
              >
                {selectMode && (
                  <button onClick={() => toggleSelect(c.id)} className="text-primary hover:text-primary/70 transition-colors">
                    {selected.has(c.id) ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4 text-muted-foreground" />}
                  </button>
                )}
                <div>
                  <p className="font-semibold text-foreground text-sm">{c.name}</p>
                  <p className="text-xs text-muted-foreground">{c.email}</p>
                </div>
                <span className="text-sm text-foreground">{c.position}</span>
                <span className={`inline-flex items-center justify-center text-sm font-bold px-2.5 py-1 rounded-lg w-fit ${scoreColor(c.score)}`}>
                  {c.score}
                </span>
                <span className="text-xs text-muted-foreground">{new Date(c.date).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })}</span>
                <div className="flex justify-end">
                  <button
                    onClick={() => onViewDetails(c)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold text-primary bg-primary/10 hover:bg-primary/20 transition-colors"
                  >
                    <Eye className="w-3.5 h-3.5" /> View Details
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// ─── ROOT APP ──────────────────────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState<Page>("login");
  const [candidates, setCandidates] = useState<Candidate[]>(SAMPLE_CANDIDATES);
  const [activeCandidate, setActiveCandidate] = useState<{ name: string; position: string; email: string } | null>(null);
  const [viewCandidate, setViewCandidate] = useState<Candidate | null>(null);

  const handleLogin = () => setPage("dashboard");
  const handleLogout = () => { setPage("login"); setActiveCandidate(null); setViewCandidate(null); };

  const handleStartInterview = (c: { name: string; position: string; email: string }) => {
    setActiveCandidate(c);
    setPage("interview");
  };

  const handleFinishInterview = (answers: Candidate["questions"]) => {
    if (!activeCandidate) return;
    const score = Math.floor(50 + Math.random() * 45);
    const newCand: Candidate = {
      id: Date.now().toString(),
      ...activeCandidate,
      score,
      date: new Date().toISOString().split("T")[0],
      questions: answers,
    };
    setViewCandidate(newCand);
    setPage("results");
  };

  const handleSaveCandidate = (c: Candidate) => {
    setCandidates(prev => [c, ...prev.filter(x => x.id !== c.id)]);
    setPage("previous-candidates");
  };

  const handleViewDetails = (c: Candidate) => {
    setViewCandidate(c);
    setPage("results");
  };

  const handleDelete = (ids: string[]) => {
    setCandidates(prev => prev.filter(c => !ids.includes(c.id)));
  };

  const withHeader = (content: React.ReactNode) => (
    <div className="min-h-screen bg-background">
      <Header currentPage={page} onNav={setPage} onLogout={handleLogout} />
      {content}
    </div>
  );

  if (page === "login") return <LoginPage onLogin={handleLogin} />;

  if (page === "dashboard") return withHeader(<Dashboard onNav={setPage} />);

  if (page === "new-candidate") return withHeader(
    <NewCandidatePage
      onStart={handleStartInterview}
      onCancel={() => setPage("dashboard")}
    />
  );

  if (page === "interview" && activeCandidate) return withHeader(
    <InterviewPage
      candidate={activeCandidate}
      onFinish={handleFinishInterview}
    />
  );

  if (page === "results" && viewCandidate) return withHeader(
    <ResultsPage
      candidate={viewCandidate}
      onBack={() => setPage("previous-candidates")}
      onSave={handleSaveCandidate}
    />
  );

  if (page === "previous-candidates") return withHeader(
    <PreviousCandidatesPage
      candidates={candidates}
      onViewDetails={handleViewDetails}
      onDelete={handleDelete}
    />
  );

  return withHeader(<Dashboard onNav={setPage} />);
}
