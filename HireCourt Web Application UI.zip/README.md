
  # HireCourt Web Application UI

  This is a code bundle for HireCourt Web Application UI. The original project is available at https://www.figma.com/design/PemI9SOPNLmGBgOoRx64zS/HireCourt-Web-Application-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  